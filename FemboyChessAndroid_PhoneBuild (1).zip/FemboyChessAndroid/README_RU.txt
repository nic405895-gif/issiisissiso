FEMBOY CHESS — Android Studio project

ВАЖНО:
Это игровой прототип. Доска, ходы, локальная игра, лазер 3x3 и отмена хода работают.
Шахматные правила в этой первой версии упрощены: нет проверки шаха/мата, рокировки и взятия на проходе. Если пешка доходит до края, превращается в ферзя. Лазер очищает центральные клетки c3-e5 (3x3); король тоже может быть уничтожен.

КАК ПОЛУЧИТЬ APK:
1. Установи Android Studio: https://developer.android.com/studio
2. Распакуй ZIP.
3. В Android Studio выбери Open и укажи папку FemboyChess.
4. Дождись окончания Gradle Sync (нужен интернет для загрузки Android Gradle Plugin).
5. Открой Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk
7. Перешли APK на телефон и разреши установку из этого источника.

Для сборки нужен JDK 17 и Android SDK Platform 35. Проект не содержит готового APK.
